package com.wf.training.spring.mvc.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.wf.training.spring.mvc.model.Employee;

@Controller
@RequestMapping("/employee")
public class EmployeeController {

	// @RequestMapping("/home") // /employee/home
	// multiple urls map to same method
	@RequestMapping(value = { "/home", "/dashboard","index"}) // /employee/home
	public String home() {
		return "employee-home";
	}
	
	@RequestMapping() // default method for parent url
	public String defaultResponse() {
		return "employee-base";
	}
	
	// Fallback mapping url (bad urls)
	@RequestMapping("*") 
	public String fallback() {
		return "employee-error";
	}
	
	@RequestMapping("/profile") 
	public String profile() {
		return "employee-profile";
	}
	
	// request object provided if required
	// servlet api way 
	// @RequestMapping("/save")
	// only for post type
	/*@RequestMapping(value = {"/save"}, method = RequestMethod.POST)
	public String saveProfile(HttpServletRequest request) {
		String uname = request.getParameter("uname");
		String email = request.getParameter("email");
		System.out.println("NAME  : " + uname);
		System.out.println("EMAIL : " + email);
		return "employee-confirm";
	}*/
	
	// spring way : client data a Request Params
	/*@RequestMapping(value = {"/save"}, method = RequestMethod.POST)
	// public String saveProfile( String uname, String email) {
	public String saveProfile(@RequestParam("uname") String employeeName,
							  @RequestParam(value = "email", required = false, defaultValue = "dummy@mail.com") String email) {
		System.out.println("NAME  : " + employeeName);
		System.out.println("EMAIL : " + email);
		return "employee-confirm";
	}*/
	
	// spring abstract way
	/*@RequestMapping(value = {"/save"}, method = RequestMethod.POST)
	public String saveProfile(Employee employee, Model model) {
		// put my data in model container
		// model.addAttribute("uname", employee.getUname());
		// model.addAttribute("email", employee.getEmail());
		model.addAttribute("employee", employee);
		
		return "employee-confirm";
	}*/
	
	// spring abstract way
	@RequestMapping(value = {"/save"}, method = {RequestMethod.POST})
	public ModelAndView saveProfile(Employee employee) {
		ModelAndView mv = new ModelAndView("employee-confirm");
		mv.addObject("employee", employee);
		return mv;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
