package com.wf.training.spring.mvc.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class TestController {
	
	/*@RequestMapping("/profile")
	public String profile() {
		// add bussiness logic
		
		// respond back with view page name
		return "profile-page";
	}*/
}
