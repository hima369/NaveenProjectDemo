package com.wf.training.spring.mvc.model;

public class Employee {

	private String uname;
	private String email;
	
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getEmail() {
		if(email.equals(""))
			return "dummy@mail.com";
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	
}
