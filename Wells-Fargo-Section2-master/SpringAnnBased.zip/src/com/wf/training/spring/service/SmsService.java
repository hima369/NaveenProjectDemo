package com.wf.training.spring.service;

import org.springframework.stereotype.Component;

// @Component("mservice")
public class SmsService implements IMessageService {

	@Override
	public String sendMessage(String to, String message) {
		return "SMS send to : " + to + "[ " + message + " ]";
	}

}
