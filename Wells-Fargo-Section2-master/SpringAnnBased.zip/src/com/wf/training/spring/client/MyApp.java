package com.wf.training.spring.client;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.wf.training.spring.service.EmailService;
import com.wf.training.spring.service.IMessageService;

public class MyApp {

	public static void main(String[] args) {
		
		// create a container
		ClassPathXmlApplicationContext context =
				new ClassPathXmlApplicationContext("applicationContext.xml");
		
		// retrieve a bean
		// IMessageService service = context.getBean("emailService", IMessageService.class);
		IMessageService service = context.getBean("mservice", IMessageService.class);
		String ack = service.sendMessage("someone@mail.com", "Hello!!!");
		System.out.println(ack);
		
		context.close();
		
	}

}















