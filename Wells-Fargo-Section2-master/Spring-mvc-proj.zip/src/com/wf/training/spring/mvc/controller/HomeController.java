package com.wf.training.spring.mvc.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

// container for multiple request handling method
// This class is registered in handler mapper

@Controller
public class HomeController {
	
	// Action/Handler methods
	/*
	 * 1. Access modifier : public
	 * 2. Return type : String ( view name )
	 * 3. Name : any
	 * 4. Parameter : depends on req
	 * 5. URL Mapped 
	 */
	// to respond to root URL
	@RequestMapping("/")
	public String home() {
		// add bussiness logic
		
		// respond back with view page name
		return "index";
	}
	
	@RequestMapping("/profile")
	public String profile() {
		// add bussiness logic
		
		// respond back with view page name
		return "profile-page";
	}
}
