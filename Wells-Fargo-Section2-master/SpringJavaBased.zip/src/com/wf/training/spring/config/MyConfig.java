package com.wf.training.spring.config;

import java.time.LocalTime;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

import com.wf.training.spring.service.support.IFortuneService;
import com.wf.training.spring.service.support.PersonalFortune;
import com.wf.training.spring.service.support.ProfessionalFortune;

// read/treat this class as config class
@Configuration
// packages to look for component
@ComponentScan("com.wf.training.spring")
// loading the property files
@PropertySource("classpath:literalrepo.properties")
public class MyConfig {

	// logic to expose the bean of a particular fortune Service
	// method to contain that logic
	// object returned by method should be managed by container
	@Bean
	public IFortuneService fortuneService() {
		if(LocalTime.now().getHour() < 10 || LocalTime.now().getHour() > 17)
			return new PersonalFortune();
		return new ProfessionalFortune();
	}
}








