package com.wf.training.spring.service;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.wf.training.spring.service.support.IFortuneService;

@Component("mservice")
@Scope("singleton")
public class EmailService implements IMessageService {
	
	// dependency
	// @Autowired
	private IFortuneService fortuneService;
	
	@Value("${msg.email.sender}")
	private String sender;
	
	// Constructor based
	@Autowired // optional for constructor
	public EmailService(IFortuneService fortuneService) {
		this.fortuneService = fortuneService;
	}
	
	/*@Autowired
	@Qualifier("professionalFortune")
	// public void xyz(IFortuneService fortuneService) {
	public void setFortuneService(IFortuneService fortuneService) {
		this.fortuneService = fortuneService;
	}*/
	
	@PostConstruct
	public void myInit() {
		System.out.println("\nInitialized\n");
	}
	
	@Override
	public String sendMessage(String to, String message) {
		return "Email send to : " + to + "[ " + message + " ]" +
				"\nSender : " + this.sender + 
				"\n" + this.fortuneService.dailyFortune();
				
	}
	
	@PreDestroy
	public void myCleanUp() {
		System.out.println("\nClean Up\n");
	}
}
