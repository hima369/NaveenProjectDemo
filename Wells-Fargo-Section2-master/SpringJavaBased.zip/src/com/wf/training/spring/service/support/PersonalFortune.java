package com.wf.training.spring.service.support;

import org.springframework.stereotype.Component;


public class PersonalFortune implements IFortuneService {

	@Override
	public String dailyFortune() {
		return "Today is your lucky day!";
	}

}
