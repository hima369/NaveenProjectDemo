package com.wf.training.spring.service.support;

public interface IFortuneService {
	public String dailyFortune();
}
