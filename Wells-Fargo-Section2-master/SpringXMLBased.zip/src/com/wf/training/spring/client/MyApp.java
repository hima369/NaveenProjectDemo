package com.wf.training.spring.client;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.wf.training.spring.service.EmailService;
import com.wf.training.spring.service.IMessageService;

public class MyApp {

	public static void main(String[] args) {
		// traditional way (hard code-tight coupling)
		/*EmailService service = new EmailService();
		String ack = service.sendMessage("someone@mail.com", "Hello All");
		System.out.println(ack);*/
		
		// Want to outsource
		// Create a spring container - need to tell config to follow (XML)
		// ClassPathXmlApplicationContext // represents Spring Container configured by XML file
		ClassPathXmlApplicationContext context =
				new ClassPathXmlApplicationContext("applicationContext.xml"); // xml where config reside
		
		// demand-retrieve from spring container
		IMessageService service = context.getBean("mservice", IMessageService.class);
		String ack = service.sendMessage("someone@mail.com", "Hello All");
		System.out.println(ack);
		
		IMessageService servicePro = context.getBean("proservice", IMessageService.class);
		ack = servicePro.sendMessage("newperson@mail.com", "Hello All");
		System.out.println(ack);
		
		// shut down the container
		context.close();
		
	}

}















