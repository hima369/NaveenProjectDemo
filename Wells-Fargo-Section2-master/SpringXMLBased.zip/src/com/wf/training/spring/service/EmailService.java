package com.wf.training.spring.service;

import com.wf.training.spring.service.support.IFortuneService;

public class EmailService implements IMessageService {

	private static int count = 0;
	// will require instance of Fortune service (dependency)
	// we want it to be injected 
	private IFortuneService fortuneService;
	
	private String sender;
	
	public EmailService() {
		count++;
		System.out.println("Email Instance created!");
	}
	
	// Constructor based DI
	/*public EmailService(IFortuneService fortuneService) {
		this.fortuneService = fortuneService;
	}*/
	
	// setter based DI : Correct naming convention
	public void setFortuneService(IFortuneService fortuneService) {
		this.fortuneService = fortuneService;
	}
	
	public void setSender(String sender) {
		this.sender = sender;
	}
	
	private void myInit() {
		System.out.println("\n" + "Initiated" + "\n");
	}
	
	
	@Override
	public String sendMessage(String to, String message) {
		return "Email send to : " + to + "[ " + message + " ]" +
				"\nSend By : " + this.sender + 
				"\n" + this.fortuneService.dailyFortune() +
				"\nInstances available :" + count; 
				
	}
	
	private void myCleanUp() {
		System.out.println("\n" + "Cleanup" + "\n");
	}

}
