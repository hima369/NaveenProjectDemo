package com.wf.training.spring.service;

public interface IMessageService {
	public String sendMessage(String to, String message);
}
